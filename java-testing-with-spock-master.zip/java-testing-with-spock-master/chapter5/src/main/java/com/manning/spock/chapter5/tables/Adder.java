package com.manning.spock.chapter5.tables;

public class Adder {
	
	public int add(int a, int b)
	{
		return a+b;
	}

}
