package com.manning.spock.chapter4.structure;

public class DefaultPriceProvider {

}
