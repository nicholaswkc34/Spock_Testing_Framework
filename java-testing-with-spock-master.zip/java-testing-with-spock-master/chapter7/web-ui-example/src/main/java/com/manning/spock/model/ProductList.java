package com.manning.spock.model;

import java.util.ArrayList;
import java.util.List;

public class ProductList {

	private List<Product> allProducts = new ArrayList<>();

	public List<Product> getAllProducts() {
		return allProducts;
	}
	
	
	
}
