package com.manning.spock.chapter6.stubs;

public interface ServiceLocator {
	WarehouseInventory getWarehouseInventory();
}
