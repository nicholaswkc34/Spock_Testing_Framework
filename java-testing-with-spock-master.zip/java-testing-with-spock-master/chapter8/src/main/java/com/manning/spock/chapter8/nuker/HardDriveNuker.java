package com.manning.spock.chapter8.nuker;

public class HardDriveNuker {

	public void deleteHardDriveNow() {
		System.out.println("Cleaning hard disk");
	}
}
