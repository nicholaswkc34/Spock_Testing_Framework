package com.manning.spock.chapter2

String firstName = "Susan"
def lastName = "Ivanova"
def fullName = "$firstName $lastName"
println fullName
