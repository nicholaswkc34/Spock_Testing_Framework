package com.manning.spock.chapter2

class Person {
	String firstName
	String lastName
	int age
}



