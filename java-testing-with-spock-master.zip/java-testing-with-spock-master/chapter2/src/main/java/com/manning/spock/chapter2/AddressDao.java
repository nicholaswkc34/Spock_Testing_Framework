package com.manning.spock.chapter2;

public interface AddressDao {

	Address load(Long id);
}
