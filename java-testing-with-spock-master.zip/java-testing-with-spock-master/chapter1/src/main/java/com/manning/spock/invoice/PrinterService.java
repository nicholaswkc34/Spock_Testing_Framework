package com.manning.spock.invoice;

public interface PrinterService {

	void printInvoice(Invoice invoice);
}
