package com.manning.spock.chapter1;

public class Adder {
	
	public int add(int a, int b) {
//		return a+b +1;
		return a+b;
	}

}
